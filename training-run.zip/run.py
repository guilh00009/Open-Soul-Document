# ---------- Setup ----------
import os, json
from typing import Any
from benchmax.envs.base_env import BaseEnv
from benchmax.envs.example_id import make_example
from benchmax.envs.types import Example, Messages, ToolDefinition
from benchmax.envs.reward_helpers import extract_completion_text
RUN_NAME = "my-run"
BASE_MODEL = "Qwen/Qwen3.5-4B"


# ---------- Environment Definition ----------
class CustomEnv(BaseEnv):
    """Your custom training environment. Fill in the system prompt, dataset
    preprocessing, tools, and reward logic below to define and score your
    task."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    # ---------- System Prompt ----------
    system_prompt = """

"""

    # ---------- Dataset Preprocess ----------
    @classmethod
    def dataset_preprocess(cls, example: Any, **kwargs) -> Example:
        return make_example(
            prompt_messages=[{"role": "user", "content": example["prompt"]}],
            task={"ground_truth": example.get("ground_truth", "")},
            system_prompt=cls.system_prompt,
        )

    # ---------- Rewards ----------
    async def compute_reward(self, rollout_id, messages, task=None, **kwargs):
        return {}

    # ---------- Tools ----------
    async def list_tools(self) -> list[ToolDefinition]:
        return []

    async def run_tool(self, rollout_id: str, tool_name: str, **tool_args) -> Any:
        return ""

# ---------- Bundle Args ----------
# Installed on the trainer so the env unpickles (forwarded to dump_bundle).
pip_dependencies = ["openai"]


# ---------- Dataset ----------
# Each example needs a "prompt" (model input) and "ground_truth" (whatever
# your rewards score against). Add your own JSONL splits next to this script:
train_data = [json.loads(line) for line in open("train_dataset.jsonl")]
eval_data = [json.loads(line) for line in open("eval_dataset.jsonl")]



import dataclasses
import os
from benchmax.platform import (
    TrainerClient,
    upload_training_run,
    validate_env,
    ensure_session,
)

ensure_session()

# ---------- Validate ----------
# Smoke-test 2 examples on the platform (env bundled inline — no upload)
# before paying to upload the full dataset or for GPU time.
if not validate_env(
    env_class=CustomEnv,
    env_args={},
    train_dataset=train_data,
    eval_dataset=eval_data,
    local=False,
    pip_dependencies=pip_dependencies,
    # llm_base_url="https://api.openai.com/v1",
    # llm_api_key=os.environ["OPENAI_API_KEY"],
):
    raise SystemExit("Validation failed — fix the env or dataset before launching.")

# ---------- Upload ----------
# Bundle the env class + upload datasets + bundle to platform storage.
uploaded = upload_training_run(
    env_class=CustomEnv,
    train_dataset=train_data,
    eval_dataset=eval_data,
    run_name=RUN_NAME,
    constructor_args={},
    pip_dependencies=pip_dependencies,
)

# ---------- Launch ----------
run_id = TrainerClient().launch_training_run(
    training_run_type="simple",
    name=RUN_NAME,
    launcher_args={"model": BASE_MODEL},
    **dataclasses.asdict(uploaded),
)
print(f"Training run: https://app.castform.com/train/{run_id}")
